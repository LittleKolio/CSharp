﻿INSERT INTO Villains
VALUES(@VillainName, 'evil');