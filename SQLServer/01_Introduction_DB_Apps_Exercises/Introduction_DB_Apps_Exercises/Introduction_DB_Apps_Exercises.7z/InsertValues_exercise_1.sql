﻿INSERT INTO Towns
VALUES
	('Sofia', 'Bulgaria'),
	('Plovdiv', 'Bulgaria'),
	('Berlin', 'Germany'),
	('Paris', 'France'),
	('Liverpool', 'England')

INSERT INTO Minions
VALUES
	('Kevin', 11, 1),
	('Bob', 13, 2),
	('Steward', 19, 3),
	('Simon', 22, 4),
	('Jimmy', 30, 5)

INSERT INTO Villains
VALUES
	('Kele6', 'good'),
	('Carvul', 'bad'),
	('Magare', 'evil'),
	('Tartei', 'super evil'),
	('Tiuflek', 'evil')

INSERT INTO MinionsVillains
VALUES
	(2, 1),
	(2, 3),
	(3, 1),
	(3, 3),
	(3, 4),
	(4, 2),
	(4, 3),
	(4, 4),
	(5, 1),
	(5, 2)
