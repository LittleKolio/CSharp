﻿INSERT INTO Towns(Name)
VALUES(@TownName);