﻿using System;

public class ConsoleWriter
{
    public void WriteLine(string output) => Console.WriteLine(output);
}
