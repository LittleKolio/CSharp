﻿public abstract class Driver
{
    protected Driver(string name, Car car)
    {
        this.name = name;
        this.Car = car;
    }

    //private double fuelConsumptionPerKm;
    private string name;
    private double totalTime;

    public double FuelConsumptionPerKm { get; protected set; }
    public Car Car { get; private set; }
    public double TotalTime
    {
        get { return this.totalTime; }
        set { this.totalTime = value; }
    }
    public virtual double Speed => this.Car.Speed;

    public void IncreaseTotalTime(int trackLength)
    {
        this.TotalTime += 60 / (trackLength / this.Speed);
    }

    public void DecreaseFuelAmount(int trackLength)
    {
        this.Car.FuelAmount -= trackLength * this.FuelConsumptionPerKm;
    }
}