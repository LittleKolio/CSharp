﻿public class EnduranceDriver : Driver
{
    public EnduranceDriver(string name, Car car) 
        : base(name, 1.5, car)
    {
    }
}