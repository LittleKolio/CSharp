﻿public class Track
{
    public Track(int lapsNumber, int trackLength)
    {
        this.lapsNumber = lapsNumber;
        this.trackLength = trackLength;
    }

    private int lapsNumber;
    private int trackLength;
}