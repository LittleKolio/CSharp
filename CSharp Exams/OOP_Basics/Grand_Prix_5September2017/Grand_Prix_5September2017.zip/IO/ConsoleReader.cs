﻿using System;

public class ConsoleReader
{
    public string ReadLine() => Console.ReadLine();
}
