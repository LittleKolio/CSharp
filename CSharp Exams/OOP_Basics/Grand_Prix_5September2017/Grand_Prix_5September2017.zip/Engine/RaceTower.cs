﻿using System;
using System.Collections.Generic;
using System.Linq;

public class RaceTower
{
    public RaceTower()
    {
        this.driverFactory = new DriverFactory();
        this.carFactory = new CarFactory();
        this.tyreFactory = new TyreFactory();
    }

    public List<Driver> drivers;
    public List<Driver> dropoutDrivers;

    private Track track;
    private DriverFactory driverFactory;
    private CarFactory carFactory;
    private TyreFactory tyreFactory;

    public void SetTrackInfo(int lapsNumber, int trackLength)
    {
        this.track = new Track(lapsNumber, trackLength);
    }
    public void RegisterDriver(List<string> commandArgs)
    {
        List<string> driverArgs = commandArgs.Take(2).ToList();
        List<string> carArgs = commandArgs.Skip(2).Take(2).ToList();
        List<string> tyreArgs = commandArgs.Skip(4).ToList();

        Tyre tyre = this.tyreFactory.GetTyre(tyreArgs);
        if (tyre == null)
        {
            return;
        }

        Car car = this.carFactory.GetCar(carArgs, tyre);
        if (car == null)
        {
            return;
        }

        Driver driver = this.driverFactory.GetDriver(driverArgs, car);
        if (driver == null)
        {
            return;
        }

        this.drivers.Add(driver);
    }

    public void DriverBoxes(List<string> commandArgs)
    {
        throw new InvalidOperationException();
    }

    public string CompleteLaps(List<string> commandArgs)
    {
        //TODO: Add some logic here …
        throw new InvalidOperationException();
    }

    public string GetLeaderboard()
    {
        //TODO: Add some logic here …
        throw new InvalidOperationException();
    }

    public void ChangeWeather(List<string> commandArgs)
    {
        //TODO: Add some logic here …
        throw new InvalidOperationException();
    }
}