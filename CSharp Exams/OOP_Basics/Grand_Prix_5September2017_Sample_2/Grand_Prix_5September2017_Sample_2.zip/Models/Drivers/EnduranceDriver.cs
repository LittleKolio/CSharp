﻿public class EnduranceDriver : Driver
{
    private const double fuelConsumptionPerKm = 1.5;

    public EnduranceDriver(string name, Car car) 
        : base(name, car)
    {
        base.FuelConsumptionPerKm = fuelConsumptionPerKm;
    }
}