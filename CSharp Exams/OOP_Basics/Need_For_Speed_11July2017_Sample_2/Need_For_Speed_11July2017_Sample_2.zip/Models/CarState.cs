﻿public enum CarState
{
    waiting,
    park,
    race
}