﻿public interface IBrowsing
{
    string Site { get; }
    string WorldWideWeb();
}
