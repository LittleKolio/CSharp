﻿public interface ICalling
{
    string Number { get; }
    string CallOtherPhones();
}
