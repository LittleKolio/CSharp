﻿public interface ISociety
{
    string Id { get; }
    bool CheckId(string digits);
}
