﻿namespace Reflection_Exercises
{
    public interface IAttacker
    {
        int AttackDamage { get; }
    }
}
