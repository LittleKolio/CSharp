﻿namespace Reflection_Exercises
{
    public interface IExecutable
    {
        string Execute();
    }
}
