﻿namespace Reflection_Exercises
{
    public interface IDestroyable
    {
        int Health { get; set; }
    }
}
