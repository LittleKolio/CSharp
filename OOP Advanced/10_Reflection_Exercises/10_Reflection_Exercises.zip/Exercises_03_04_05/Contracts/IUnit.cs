﻿namespace Reflection_Exercises
{
    public interface IUnit : IDestroyable, IAttacker
    {

    }
}
