﻿namespace Reflection_Exercises
{
    public interface IUnitFactory
    {
        IUnit CreateUnit(string unitType);
    }
}
