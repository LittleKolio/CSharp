﻿namespace Reflection_Exercises
{
    public interface IRunnable
    {
        void Run();
    }
}
